/**
*The purpose of this class is to model a television
*Your name and today�s date
*/
import java.util.Scanner;
public class Television {
	

	final String MANUFACTURER;//  hold the brand name
	final int SCREEN_SIZE;//hold the size of the television screen.
	boolean powerOn;//hold the value true if the power is on, and false if the power is off.
	int channel;//hold the value of the station that the television is showing.
	int volume;//hold a number value representing the loudness (0 being no sound).


//object will also be able to control the state of its attributes
	public Television(String brand, int size) {
		this.MANUFACTURER = brand;
		this.SCREEN_SIZE = size;
		this.powerOn = false;
		this.volume = 20;
		this.channel =2;
		Scanner input = new Scanner(System.in);
		
	
	}

//will return the value stored in the channel field.

	public int getChannel(){
		return channel;
	}
//will return the value stored in the volume field.

	public int getVolume() {
		return volume;
	}
//will return the constant value stored in the MANUFACTURER field.
	
	public String getManufacturer() {
		return MANUFACTURER;
	}
// will return the constant value stored in the SCREEN_SIZE field.
	public int getScreenSize() {
		return SCREEN_SIZE;
	}
//will store the desired station in the channel field.	
	public void setChannel(int station) {
		channel = station;
	}
/*will toggle the power between on and off, changing the value stored in the powerOn field 
 * from true to false or from false to true.
 */
	public void power() {
		powerOn = !powerOn;
	}
//will increase the value stored in the volume field by 1.

	public void increaseVolume() {
		volume +=1;
	}
//will decrease the value stored in the volume field by 1.

	public void decreaseVolume() {
		volume -= 1;
	}

	
	
}
	

